// ============================================================
//  Hospital Management System - Node.js + Express Backend
//  File: server.js
// ============================================================

const express = require('express');
const mysql   = require('mysql2/promise');
const cors    = require('cors');
const path    = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ───────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── DB Connection Pool ───────────────────────────────────────
const pool = mysql.createPool({
  host:     process.env.DB_HOST     || 'localhost',
  user:     process.env.DB_USER     || 'root',
  password: process.env.DB_PASS     || '',
  database: process.env.DB_NAME     || 'hospital_db',
  waitForConnections: true,
  connectionLimit:    10,
});

// ── Helper ───────────────────────────────────────────────────
const db = async (sql, params = []) => {
  const [rows] = await pool.execute(sql, params);
  return rows;
};

// ============================
//  DASHBOARD STATS
// ============================
app.get('/api/stats', async (req, res) => {
  try {
    const [[{ patients }]]     = await pool.execute('SELECT COUNT(*) AS patients FROM patients');
    const [[{ doctors }]]      = await pool.execute('SELECT COUNT(*) AS doctors FROM doctors');
    const [[{ appointments }]] = await pool.execute("SELECT COUNT(*) AS appointments FROM appointments WHERE status='Scheduled'");
    const [[{ records }]]      = await pool.execute('SELECT COUNT(*) AS records FROM medical_records');
    res.json({ patients, doctors, appointments, records });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ============================
//  DEPARTMENTS
// ============================
app.get('/api/departments', async (req, res) => {
  try { res.json(await db('SELECT * FROM departments ORDER BY name')); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// ============================
//  DOCTORS
// ============================
app.get('/api/doctors', async (req, res) => {
  try {
    res.json(await db(`
      SELECT d.*, dep.name AS department_name
      FROM doctors d
      LEFT JOIN departments dep ON d.department_id = dep.id
      ORDER BY d.full_name
    `));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/doctors/:id', async (req, res) => {
  try {
    const rows = await db(`
      SELECT d.*, dep.name AS department_name
      FROM doctors d LEFT JOIN departments dep ON d.department_id = dep.id
      WHERE d.id = ?`, [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Doctor not found' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/doctors', async (req, res) => {
  try {
    const { full_name, specialization, department_id, phone, email, available_days } = req.body;
    const result = await db(
      'INSERT INTO doctors (full_name,specialization,department_id,phone,email,available_days) VALUES (?,?,?,?,?,?)',
      [full_name, specialization, department_id, phone, email, available_days]
    );
    res.status(201).json({ id: result.insertId, message: 'Doctor added' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/doctors/:id', async (req, res) => {
  try {
    const { full_name, specialization, department_id, phone, email, available_days } = req.body;
    await db(
      'UPDATE doctors SET full_name=?,specialization=?,department_id=?,phone=?,email=?,available_days=? WHERE id=?',
      [full_name, specialization, department_id, phone, email, available_days, req.params.id]
    );
    res.json({ message: 'Doctor updated' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/doctors/:id', async (req, res) => {
  try {
    await db('DELETE FROM doctors WHERE id=?', [req.params.id]);
    res.json({ message: 'Doctor deleted' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ============================
//  PATIENTS
// ============================
app.get('/api/patients', async (req, res) => {
  try {
    const search = req.query.search ? `%${req.query.search}%` : '%';
    res.json(await db(
      'SELECT * FROM patients WHERE full_name LIKE ? OR phone LIKE ? ORDER BY full_name',
      [search, search]
    ));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/patients/:id', async (req, res) => {
  try {
    const rows = await db('SELECT * FROM patients WHERE id=?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Patient not found' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/patients', async (req, res) => {
  try {
    const { full_name, dob, gender, blood_group, phone, email, address } = req.body;
    const result = await db(
      'INSERT INTO patients (full_name,dob,gender,blood_group,phone,email,address) VALUES (?,?,?,?,?,?,?)',
      [full_name, dob, gender, blood_group, phone, email, address]
    );
    res.status(201).json({ id: result.insertId, message: 'Patient registered' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/patients/:id', async (req, res) => {
  try {
    const { full_name, dob, gender, blood_group, phone, email, address } = req.body;
    await db(
      'UPDATE patients SET full_name=?,dob=?,gender=?,blood_group=?,phone=?,email=?,address=? WHERE id=?',
      [full_name, dob, gender, blood_group, phone, email, address, req.params.id]
    );
    res.json({ message: 'Patient updated' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/patients/:id', async (req, res) => {
  try {
    await db('DELETE FROM patients WHERE id=?', [req.params.id]);
    res.json({ message: 'Patient deleted' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ============================
//  APPOINTMENTS
// ============================
app.get('/api/appointments', async (req, res) => {
  try {
    res.json(await db(`
      SELECT a.*, p.full_name AS patient_name, d.full_name AS doctor_name
      FROM appointments a
      JOIN patients p ON a.patient_id = p.id
      JOIN doctors  d ON a.doctor_id  = d.id
      ORDER BY a.appointment_dt DESC
    `));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/appointments', async (req, res) => {
  try {
    const { patient_id, doctor_id, appointment_dt, reason, status, notes } = req.body;
    const result = await db(
      'INSERT INTO appointments (patient_id,doctor_id,appointment_dt,reason,status,notes) VALUES (?,?,?,?,?,?)',
      [patient_id, doctor_id, appointment_dt, reason, status || 'Scheduled', notes]
    );
    res.status(201).json({ id: result.insertId, message: 'Appointment booked' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/appointments/:id', async (req, res) => {
  try {
    const { patient_id, doctor_id, appointment_dt, reason, status, notes } = req.body;
    await db(
      'UPDATE appointments SET patient_id=?,doctor_id=?,appointment_dt=?,reason=?,status=?,notes=? WHERE id=?',
      [patient_id, doctor_id, appointment_dt, reason, status, notes, req.params.id]
    );
    res.json({ message: 'Appointment updated' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/appointments/:id', async (req, res) => {
  try {
    await db('DELETE FROM appointments WHERE id=?', [req.params.id]);
    res.json({ message: 'Appointment deleted' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ============================
//  MEDICAL RECORDS
// ============================
app.get('/api/records', async (req, res) => {
  try {
    res.json(await db(`
      SELECT r.*, p.full_name AS patient_name, d.full_name AS doctor_name
      FROM medical_records r
      JOIN patients p ON r.patient_id = p.id
      JOIN doctors  d ON r.doctor_id  = d.id
      ORDER BY r.visit_date DESC
    `));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/records', async (req, res) => {
  try {
    const { patient_id, doctor_id, visit_date, diagnosis, prescription, notes } = req.body;
    const result = await db(
      'INSERT INTO medical_records (patient_id,doctor_id,visit_date,diagnosis,prescription,notes) VALUES (?,?,?,?,?,?)',
      [patient_id, doctor_id, visit_date, diagnosis, prescription, notes]
    );
    res.status(201).json({ id: result.insertId, message: 'Record added' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/records/:id', async (req, res) => {
  try {
    await db('DELETE FROM medical_records WHERE id=?', [req.params.id]);
    res.json({ message: 'Record deleted' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Start ────────────────────────────────────────────────────
app.listen(PORT, () => console.log(`🏥 Hospital API running → http://localhost:${PORT}`));
