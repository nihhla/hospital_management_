# 🏥 MediCore — Hospital Management System
### Node.js + Express + MySQL

---

## Project Structure

```
hospital-system/
├── server.js              ← Express backend (REST API)
├── package.json
├── public/
│   └── index.html         ← Frontend (HTML + CSS + JS)
└── database/
    └── schema.sql         ← MySQL schema + seed data
```

---

## ⚙️ Setup Instructions

### 1. Install MySQL & Create Database

```sql
-- In MySQL CLI or MySQL Workbench:
SOURCE /path/to/hospital-system/database/schema.sql;
```

### 2. Install Node.js Dependencies

```bash
cd hospital-system
npm install
```

### 3. Configure Database (optional)

Edit `server.js` lines 15–20 or set environment variables:

```bash
export DB_HOST=localhost
export DB_USER=root
export DB_PASS=your_password
export DB_NAME=hospital_db
```

### 4. Start the Server

```bash
# Production
npm start

# Development (auto-restart)
npm run dev
```

### 5. Open in Browser

```
http://localhost:3000
```

---

## 📡 API Endpoints

| Method | Endpoint              | Description              |
|--------|-----------------------|--------------------------|
| GET    | /api/stats            | Dashboard stats          |
| GET    | /api/departments      | List departments         |
| GET    | /api/patients         | List patients            |
| POST   | /api/patients         | Add patient              |
| PUT    | /api/patients/:id     | Update patient           |
| DELETE | /api/patients/:id     | Delete patient           |
| GET    | /api/doctors          | List doctors             |
| POST   | /api/doctors          | Add doctor               |
| PUT    | /api/doctors/:id      | Update doctor            |
| DELETE | /api/doctors/:id      | Delete doctor            |
| GET    | /api/appointments     | List appointments        |
| POST   | /api/appointments     | Book appointment         |
| DELETE | /api/appointments/:id | Delete appointment       |
| GET    | /api/records          | List medical records     |
| POST   | /api/records          | Add medical record       |
| DELETE | /api/records/:id      | Delete medical record    |

---

## 🗄️ Database Tables

- **departments** — Hospital departments (Cardiology, Neurology…)
- **doctors** — Doctor profiles with specialization & department
- **patients** — Patient registration with personal details
- **appointments** — Scheduled patient-doctor appointments
- **medical_records** — Diagnosis and prescription history

---

## ✨ Features

- ✅ Full CRUD for Patients, Doctors, Appointments, Medical Records
- ✅ Dashboard with live stats
- ✅ Patient search by name/phone
- ✅ Appointment status tracking (Scheduled / Completed / Cancelled)
- ✅ Relational data (JOINs between tables)
- ✅ Seed data included for quick demo
