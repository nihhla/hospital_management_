-- ============================================================
--  Hospital / Clinic Management System - MySQL Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS hospital_db;
USE hospital_db;

-- ------------------------------------------------------------
-- DEPARTMENTS
-- ------------------------------------------------------------
CREATE TABLE departments (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL UNIQUE,
  description TEXT,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- DOCTORS
-- ------------------------------------------------------------
CREATE TABLE doctors (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  full_name       VARCHAR(150) NOT NULL,
  specialization  VARCHAR(100) NOT NULL,
  department_id   INT,
  phone           VARCHAR(20),
  email           VARCHAR(100) UNIQUE,
  available_days  VARCHAR(100) DEFAULT 'Mon-Fri',
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
);

-- ------------------------------------------------------------
-- PATIENTS
-- ------------------------------------------------------------
CREATE TABLE patients (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  full_name    VARCHAR(150) NOT NULL,
  dob          DATE NOT NULL,
  gender       ENUM('Male','Female','Other') NOT NULL,
  blood_group  VARCHAR(5),
  phone        VARCHAR(20),
  email        VARCHAR(100),
  address      TEXT,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- APPOINTMENTS
-- ------------------------------------------------------------
CREATE TABLE appointments (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  patient_id     INT NOT NULL,
  doctor_id      INT NOT NULL,
  appointment_dt DATETIME NOT NULL,
  reason         TEXT,
  status         ENUM('Scheduled','Completed','Cancelled') DEFAULT 'Scheduled',
  notes          TEXT,
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
  FOREIGN KEY (doctor_id)  REFERENCES doctors(id)  ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- MEDICAL RECORDS
-- ------------------------------------------------------------
CREATE TABLE medical_records (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  patient_id    INT NOT NULL,
  doctor_id     INT NOT NULL,
  visit_date    DATE NOT NULL,
  diagnosis     TEXT NOT NULL,
  prescription  TEXT,
  notes         TEXT,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
  FOREIGN KEY (doctor_id)  REFERENCES doctors(id)  ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- SEED DATA
-- ------------------------------------------------------------
INSERT INTO departments (name, description) VALUES
  ('Cardiology',    'Heart and cardiovascular system'),
  ('Neurology',     'Brain, spine and nervous system'),
  ('Orthopedics',   'Bones, joints and muscles'),
  ('Pediatrics',    'Medical care for infants and children'),
  ('General Medicine', 'Primary care and general health');

INSERT INTO doctors (full_name, specialization, department_id, phone, email, available_days) VALUES
  ('Dr. Arjun Menon',    'Cardiologist',         1, '9876500001', 'arjun@clinic.com',   'Mon-Fri'),
  ('Dr. Priya Nair',     'Neurologist',          2, '9876500002', 'priya@clinic.com',   'Mon-Sat'),
  ('Dr. Rahul Krishnan', 'Orthopedic Surgeon',   3, '9876500003', 'rahul@clinic.com',   'Tue-Sat'),
  ('Dr. Sneha Thomas',   'Pediatrician',         4, '9876500004', 'sneha@clinic.com',   'Mon-Fri'),
  ('Dr. Vivek Pillai',   'General Physician',    5, '9876500005', 'vivek@clinic.com',   'Mon-Sat');

INSERT INTO patients (full_name, dob, gender, blood_group, phone, email, address) VALUES
  ('Aisha Fathima',  '1990-05-14', 'Female', 'O+',  '9876543210', 'aisha@mail.com',  'Tirur, Kerala'),
  ('Mohammed Riyas', '1985-11-22', 'Male',   'B+',  '9876543211', 'riyas@mail.com',  'Malappuram, Kerala'),
  ('Lakshmi Devi',   '2000-03-08', 'Female', 'A-',  '9876543212', 'lakshmi@mail.com','Kozhikode, Kerala');
